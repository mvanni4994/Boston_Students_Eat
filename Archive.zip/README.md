# NY_College_Eats
Ratings application that shows local restaurants using google maps api within a 10 mile radius of Columbia University, New York University, Fordham University, and Pace University.
How we stand out: Intuitive UI that is easily accessible compared to other applications.

## Motivation ##

We are NYC students studying hard and looking for a top-rated value restaurant to take a break and enjoy some food and drinks.  

## Code Style ##


## Screenshots ##


## Framework Used ##
* Bulma 

## Features ##


## Code Example ##


## API Reference ##
* Zomato API Key: 19770ef1d81d900e465460e5b29f22bb
* Spoonacular API Key: bcbf713ed7404d57a08dc53d07322fa1

## Credits ##
Lindsey Bowen, Margaret Elson, Nicholas Jazgunovich, Matt Vanni 



